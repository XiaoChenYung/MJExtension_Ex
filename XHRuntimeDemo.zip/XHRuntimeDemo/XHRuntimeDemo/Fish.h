//
//  Fish.h
//  XHRuntimeDemo
//
//  Created by craneteng on 16/4/19.
//  Copyright © 2016年 XHTeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Fish : NSObject
@property (nonatomic,copy) NSString *name;
@property (nonatomic,assign) double weight;
@end
