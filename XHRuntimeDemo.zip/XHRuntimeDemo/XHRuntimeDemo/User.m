//
//  User.m
//  XHRuntimeDemo
//
//  Created by craneteng on 16/4/19.
//  Copyright © 2016年 XHTeng. All rights reserved.
//

#import "User.h"


@implementation User

// 返回数组中都是什么类型的模型对象
- (NSString *)arrayObjectClass {
   return @"Book";
}

@end
